a=[8,15,3,22,9,11]
if len(a)>0:
    last=a[-1]
    for i in range(len(a)-1,0,-1):
        a[i]=a[i-1]
    a[0]=last
for x in a:
    print(x,end=" ")