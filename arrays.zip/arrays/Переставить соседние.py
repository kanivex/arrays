a=[10,20,30,40,50,60,70]
for i in range(0,len(a)-1,2):
    tmp=a[i]
    a[i]=a[i+1]
    a[i+1]=tmp
for x in a:
    print(x,end=" ")