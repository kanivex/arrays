q=[(1,3),(2,6),(3,8),(4,2),(5,5),(6,1),(7,7),(8,4)]

bad=False
for i in range(8):
    for j in range(i+1,8):
        x1,y1=q[i]
        x2,y2=q[j]
        if x1==x2 or y1==y2 or abs(x1-x2)==abs(y1-y2):
            bad=True

if bad:
    print("YES")
else:
    print("NO")