a=[5,8,5,12,8,5,3]
pairs=0
for i in range(len(a)):
    for j in range(i+1,len(a)):
        if a[i]==a[j]:
            pairs+=1
print(pairs)