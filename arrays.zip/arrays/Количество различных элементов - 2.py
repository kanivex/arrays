a=[9,3,14,9,7,3,21,14]
s=set(a)
print(len(s))