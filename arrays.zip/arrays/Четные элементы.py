a=[13,8,5,22,19,4,17,10]
for x in a:
    if x%2==0:
        print(x,end=" ")