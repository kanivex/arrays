a=[6,14,9,21,3,12,15]
mn=0
for x in a:
    if x%2!=0:
        if mn==0 or x<mn:
            mn=x
print(mn)