a=[-6,9,0,-3,14,7,-1,2]
k=0
for x in a:
    if x>0:
        k+=1
print(k)