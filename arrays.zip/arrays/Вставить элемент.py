a=[11,6,18,4,9,15]
k=2
c=99
a.append(0)
for i in range(len(a)-1,k,-1):
    a[i]=a[i-1]
a[k]=c
for x in a:
    print(x,end=" ")