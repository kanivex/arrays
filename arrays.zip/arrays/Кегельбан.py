n=12
shots=[(2,4),(6,9),(8,11)]
pins=["I"]*n
for l,r in shots:
    for i in range(l-1,r):
        pins[i]="."
print("".join(pins))