a=[0,9,0,0,14,6,0,23,0,5]
k=0
for i in range(len(a)):
    if a[i]!=0:
        a[k],a[i]=a[i],a[k]
        k+=1
for x in a:
    print(x,end=" ")