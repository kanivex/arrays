a=[16,9,24,7,13,5,19]
k=3
for i in range(k,len(a)-1):
    a[i]=a[i+1]
a.pop()
for x in a:
    print(x,end=" ")