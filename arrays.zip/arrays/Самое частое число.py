a=[7,2,9,7,4,7,2,11,7]
best=a[0]
best_c=0
for x in a:
    c=a.count(x)
    if c>best_c:
        best_c=c
        best=x
print(best)