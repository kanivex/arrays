a=[178,174,170,170,166,162,159]
x=168
place=1
for h in a:
    if h>=x:
        place+=1
    else:
        break
print(place)