a=[12,5,8,19,3,14,6]
n=len(a)
for i in range(n//2):
    tmp=a[i]
    a[i]=a[n-1-i]
    a[n-1-i]=tmp
for x in a:
    print(x,end=" ")