a=[8,3,11,11,6,15,2,9]
for i in range(1,len(a)):
    if a[i]>a[i-1]:
        print(a[i],end=" ")