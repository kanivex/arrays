a=[2,9,4,12,7,15,3,8]
ans=0
for i in range(1,len(a)-1):
    if a[i]>a[i-1] and a[i]>a[i+1]:
        ans+=1
print(ans)