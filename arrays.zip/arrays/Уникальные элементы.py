a=[6,11,6,4,19,11,8,4,15]
res=[]
for x in a:
    if a.count(x)==1:
        res.append(x)
for x in res:
    print(x,end=" ")