a=[7,14,2,9,11,6,3,8]
for i in range(0,len(a),2):
    print(a[i],end=" ")