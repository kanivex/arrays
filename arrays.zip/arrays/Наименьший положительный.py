a=[-12,18,-4,7,23,3,11]
mn=1000000
for x in a:
    if x>0 and x<mn:
        mn=x
print(mn)