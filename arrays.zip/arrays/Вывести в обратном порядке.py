a=[9,4,16,2,11,7]
for i in range(len(a)-1,-1,-1):
    print(a[i],end=" ")