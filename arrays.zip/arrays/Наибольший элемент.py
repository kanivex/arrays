a=[6,19,4,25,12,25,8]
mx=a[0]
idx=0
for i in range(len(a)):
    if a[i]>mx:
        mx=a[i]
        idx=i
print(mx,idx)