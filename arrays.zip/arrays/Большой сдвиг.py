def rev(a,l,r):
    while l<r:
        a[l],a[r]=a[r],a[l]
        l+=1
        r-=1

a=[9,14,3,21,7,12,5]
k=4
n=len(a)

if n>0:
    k=(-k)%n
    if k!=0:
        rev(a,0,k-1)
        rev(a,k,n-1)
        rev(a,0,n-1)

for x in a:
    print(x,end=" ")