a=[4,4,7,9,9,9,13,18,18]
cnt=1
for i in range(1,len(a)):
    if a[i]!=a[i-1]:
        cnt+=1
print(cnt)