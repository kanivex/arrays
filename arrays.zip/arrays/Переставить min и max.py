a=[14,4,27,9,18,2,11]
mn_i=0
mx_i=0
for i in range(len(a)):
    if a[i]<a[mn_i]:
        mn_i=i
    if a[i]>a[mx_i]:
        mx_i=i
a[mn_i],a[mx_i]=a[mx_i],a[mn_i]
for x in a:
    print(x,end=" ")